# -*- coding: utf-8 -*-
# ©  2008-2018 Deltatech
# See README.rst file on addons root folder for license details



from . import service_consumption
from . import service_agreement
#import account_invoice_penalty


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
